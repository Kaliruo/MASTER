chord_v1.py et node2.py sont 2 noeuds qui apprentiennent à un cercle 

test.py pour faire 2 requêtes sur ce cercle : un join et un update

Toutes les fonctions sont dans chord_tools

testRequest.py sert pour traiter les messages reçues par les noeuds.

Compiler : chord_v1.py et node2.py puis test.py