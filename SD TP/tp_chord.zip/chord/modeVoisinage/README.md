Pas de test

Toutes les fonctions sont dans chord_tools

testRequest.py sert pour traiter les messages reçues par les noeuds.